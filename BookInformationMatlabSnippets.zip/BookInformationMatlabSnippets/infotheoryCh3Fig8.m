%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration code for Information Theory: A Tutorial Introduction, JV Stone.
% Copied with kind permission from Neal Patwari.
% The MatLab code below is version R2013b. 
% This code can be downloaded from
% http://jim-stone.staff.shef.ac.uk/InformationTheoryBook.
% This file: infotheory_3_8_v1.m
% Purpose: Estimate the entropy of a two letter sequence from a sequence of English text.
% Printed output:
% fprintf('Average entropy of each letter in each pair is H=%.4f bits/letter.\n',H);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
labelfontsize=20;

% Consider characters 'abcdefghijklmnopqrstuvwxyzSPACE'
considerChars = 'abcdefghijklmnopqrstuvwxyz ';
% Make 27x27 array of letter pair counts.
count = zeros(length(considerChars)); 
% Set name of text file to be read.
fname = 'romeo.txt';
fid   = fopen(fname);
% Get first line of text.
tline = fgets(fid); % i.e. Two households, both alike in dignity,
lastLet = '';
while (tline ~= -1),
    tline = [lastLet tline];
    % Make letters lower case.
    substr = lower(tline(find(isletter(tline) | tline == 32)));
    % Convert letters to integers, 1=a, 2=b, etc.
    ordLet = charToOrderJVS(substr);
    for i=1:length(ordLet)-1
        ii=ordLet(i);
        jj= ordLet(i+1);
        % Increment 2D array of letter pairs.
        count(ii,jj) = count(ii,jj)+1;
    end
    if ~isempty(ordLet) lastLet = ordLet(end);
    else                lastLet = '';
    end
    tline = fgets(fid);
end
fclose(fid);

% Convert counts to proportions.
p = count./sum(count(:));
p1 = p(:) + eps;
H2 = sum(p1.*log2(1./p1)); % Equations 3.46.
% H2 is entropy per pair of letters, so divide by 2 for each letter.
H = H2/2;
fprintf('Average entropy of each letter in each pair ');
fprintf('is H=%.4f bits.\n',H);
% Average entropy of each letter in each pair is H=3.7298 bits.

% Plot output distribution as 2D histogram.
figure(1); 
bar3(1:27,p);
view([-32.5,30]); colormap([1 1 1]*0.8);
set(gca,'xTick',[1, 5, 10, 15, 20,  27]);
set(gca,'xTickLabel',{ 'a', 'e', 'j', 'o', 't',  'sp'});
set(gca,'yTick',[1, 5, 10, 15, 20,  27])
set(gca,'yTickLabel',{ 'a', 'e', 'j', 'o', 't',  'sp'}); 
set(gca,'xlim',[1 27]);     
set(gca,'ylim',[1 27]);
zlabel('Relative frequency');
set(gca,'Linewidth',2);
set(gca,'GridLineStyle','-');
set(gca,'FontSize',labelfontsize)
% Output: Average entropy of each letter in each pair is H=3.7298 bits.

rotate3d on;

% Plot output distribution as 2D image.
figure(2);
p1=p(2:27,2:27);
imagesc(1:27, 1:27, log(p))
set(gca,'FontSize',24)
set(gca,'xTick',[1, 5, 10, 15, 20,  27])
set(gca,'xTickLabel',{ 'a', 'e', 'j', 'o', 't',  'sp'});
set(gca,'yTick',[1, 5, 10, 15, 20,  27])
set(gca,'yTickLabel',{ 'a', 'e', 'j', 'o', 't',  'sp'});
xlabel('Character')
ylabel('Character')
colormap(gray);
axis equal
axis tight

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF FILE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%