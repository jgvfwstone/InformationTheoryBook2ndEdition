clear all; % infotheoryCh2Fig5.m
% Define list of 100 probability values between 0.01 and 1.
px = 0.01:0.01:1;
% Find surprisals of all probabilities, using Equation 2.26.
hx = log2(1./px);

% Plot figure.
figure(1);
plot(px,hx);
ylabel('Surprise = log_2 1/{\itp}(x)');
xlabel('{\it p}(x)');
set(gca,'FontSize',20);
set(gca,'Linewidth',2);

%%%%%%%%%%%%%%%%%%
