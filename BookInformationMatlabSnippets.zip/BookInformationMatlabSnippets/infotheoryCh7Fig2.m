%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration code for Information Theory: A Tutorial Introduction, JV Stone.
% Copyright: 2014, JV Stone, Psychology Department, Sheffield University, Sheffield, England.
% The MatLab code below is version R2013b. 
% This code can be downloaded from
% http://jim-stone.staff.shef.ac.uk/InformationTheoryBook.
% This file: infotheory7_2_v1.m
% Summary: The code recreates Figure 7.2 P155, using Eq. 7.40,
% which shows how the error rate increases with message length.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

P = 10;             % Input power variance
N = 1;              % Noise variance
R = 0.99;           % Entropy rate = 0.99 bits per binary digit.
C = 1;              % Channel capacity
n = 1:4000;         % Message lengths

num = 2*P*(P+N);    % Numerator of Eq 7.40
den = N*(P+2*N);    % Denominator of Eq 7.40

% Value to be passed to cumulative gaussian (erf) function.
z = sqrt(n) .* sqrt(num/den)*(R-C);
% Find probability of error.
p = 0.5+erf(z/sqrt(2))/2; % Use corrected erf function.

% Plot result
figure(1);plot(n,p,'k-','LineWidth',2);
ylabel('P(error)');
xlabel('Message length, {\it n}');
set(gca,'YLim',[0 p(1)]); 
set(gca,'Linewidth',2);
set(gca,'FontSize',20);
return
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


