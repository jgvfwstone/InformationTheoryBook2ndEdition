clear all; % infotheoryCh2Fig6.m
% Define list of coin bias values p(head) between 0.001 and 1.
phead = 0.001:0.001:1;
% Define list p(tail) values between 0.001 and 1.
ptail = 1:-0.001:0.001;
% Find entropy of all coin biases, using Equation 2.50.
Hx = phead.*log2(1./phead) + ptail.*log2(1./ptail);

% Plot figure.
figure(1);
plot(phead,Hx);
ylabel('Entropy, H(bits)');
xlabel('Probability of a head (coin bias)');
set(gca,'YLim',[0 1.1]);
set(gca,'FontSize',20);
grid on;
set(gca,'Linewidth',2);

%%%%%%%%%%%%%%%%%%
