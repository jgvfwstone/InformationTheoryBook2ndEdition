%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration code for Information Theory: A Tutorial Introduction, JV Stone.
% Copyright: 2014, JV Stone, Psychology Department, Sheffield University, Sheffield, England.
% The MatLab code below is version R2013b.
% This code can be downloaded from
% http://jim-stone.staff.shef.ac.uk/InformationTheoryBook.
% This file: infotheoryCh5Fig2.m
% Summary: Estimates entropy of Gaussian histograms with different bin widths and compares these to the known underlying differential entropy.
% Printed output:
% Analytic differential entropy of Gaussian distribution with standard deviation = 1.000 is H = 2.04710 bits.
%
% For sampled data: binwidth 		 = 1.000
% entropy of histogram			= 2.104 bits
% differential entropy of histogram	= 2.104 bits
% 
% For sampled data: binwidth 		 = 0.500
% entropy of histogram			= 3.061 bits
% differential entropy of histogram	= 2.061 bits
% 
% For sampled data: binwidth 		 = 0.100
% entropy of histogram			= 5.369 bits
% differential entropy of histogram	= 2.047 bits
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;

% Set standard deviation.
sd = 1;
x = -4:0.01:4; % set range values of Gaussian.
m = 0; % set mean of Gaussian to be 0.

n = 1e6; % Number of data points in sample.
% Analytic differential entropy of Gaussian distribution. Eq 5.47.
H0 = 0.5 * log2( 2*pi*exp(1)*sd^2 ); 
fprintf('Analytic differential entropy of Gaussian distribution ');
fprintf('with standard deviation = %.3f is H = %.5f bits.',sd,H0);
fprintf('\n\n');

% Make n samples from a Gaussian distribution.
s = randn(n,sd);   
fignum = 0;             % Set figure number.
numsds = 4; 
% Find entropy for different histogram bin widths.
for binwidth = [1 0.5 0.1] 
    fignum = fignum+1;
    
    X = -4:binwidth:4;  % Estimate entropy within +-4 sds of mean.
    N = hist(s,X);      % Make histogram based on numbins.
    N = N + eps;        % Add eps to prevent taking log of 1/zero.
    p = N/n;
    ent = sum(p.*log2(1./p));
        
    % Theoretical value of differential entropy. Eq 5.19.
    HH = H0 + log2(1/binwidth); 
    
    diffent = ent - log2(1/binwidth); % eq 5.17
    
    fprintf('For sampled data: binwidth\t= %.3f\n',binwidth);
    fprintf('Entropy of histogram\t\t= %.3f bits\n',ent);
    fprintf('Differential entropy\t\t= %.3f bits\n\n',diffent);
    
    % Make new figure.
    figure(fignum); 
    % Get histogram
    numbins = 2*numsds/binwidth; % number of bins in histogram.
    hist(s,numbins,'LineWidth',2); 
    bar(X,N,1);
    ss = ['Bin width=' num2str(binwidth) ' entropy=' num2str(ent)];
    ss = [ss ' diff entropy=' num2str(diffent)];
    title(ss);
    colormap([1 1 1]/2);
    set(gca,'XLim',[-4,4]); % Restrict range on x-axis.
    set(gca,'Linewidth',2); set(gca,'FontSize',15);
end

%%%%%
