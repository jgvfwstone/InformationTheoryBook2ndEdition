%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Demonstration code for Information Theory: A Tutorial Introduction, JV Stone.
% Copied with kind permission from Neal Patwari.
% The MatLab code below is version R2013b. 
% This code can be downloaded from
% http://jim-stone.staff.shef.ac.uk/InformationTheoryBook.
% This file: infotheoryCh3Fig4.m
% Purpose: Estimate the entropy of single letters from a sequence of English text.
% Printed output:
% Average entropy of each letter is H=4.1249 bits.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
labelfontsize=20;

% Consider characters 'abcdefghijklmnopqrstuvwxyzSPACE'
considerChars = 'abcdefghijklmnopqrstuvwxyz ';
% Make 27x1 array of letter counts.
count1d = zeros(length(considerChars),1); 
fname = 'romeo.txt'; % Set name of text file to be read.
fid   = fopen(fname);
% Get first line of text.
tline = fgets(fid); % i.e. Two households, both alike in dignity,
lastLet = '';
while (tline ~= -1),
    tline = [lastLet tline];
    % Make letters lower case.
    substr = lower(tline(find(isletter(tline) | tline == 32)));
    % Convert letters to integers, 1=a, 2=b, etc.
    ordLet = charToOrderJVS(substr);
    for i=1:length(ordLet)-1
        ii = ordLet(i);
        % Increment 1D array of letters.
        count1d(ii)=count1d(ii)+1;
    end
    if ~isempty(ordLet) lastLet = ordLet(end);
    else                lastLet = ''; end
    tline = fgets(fid);
end
fclose(fid);

% Get entropy of single letters from 1D histogram.
% Convert counts to proportions.
figure(1); 
p1d = count1d./sum(count1d(:));
p = p1d(:) + eps; % Add eps to prevent infinity.
H1 = sum(p.*log2(1./p)); % entropy, Equation 3.43.
fprintf('Average entropy of each letter is H=%.4f bits.\n',H1);
% Average entropy of each letter is H=4.1249 bits.
bar(1:27,p1d);
set(gca,'xTick',[1, 5, 10, 15, 20,  27]);
set(gca,'xTickLabel',{ 'a', 'e', 'j', 'o', 't',  'sp'});
ylabel('Relative frequency');
xlabel('Letter'); 
% Output: Average entropy of each letter is H=4.1249 bits.

set(gca,'FontSize',labelfontsize)
colormap([1 1 1]*0.8);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END OF FILE.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%